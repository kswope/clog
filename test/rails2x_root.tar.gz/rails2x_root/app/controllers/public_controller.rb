class PublicController < ApplicationController
end
