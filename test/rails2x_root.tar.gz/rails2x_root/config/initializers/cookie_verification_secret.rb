# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '57a15fe096addf867ab1b257d28412d50f44213037db14c2d2995c94707f8121f89d08e388a8434efc00dc13c6740ee983194164783893d5c2d1224e0959f48a';
